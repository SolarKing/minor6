#!/bash/bin
gcc -o client client.c client_func.c
./client 12345