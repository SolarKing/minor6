#include "defs.h"
#include <stdlib.h>

class cache{
	private:
		
		
	public:
		cache();
		void fetchMemoryRef();
		void runSim();
		void printDebug();
};
