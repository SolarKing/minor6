#include "report.h"

using namespace std;

reporter::reporter(){

}

void reporter::createReport(){

}


void reporter::GetDisplayOptions(){

}