#include <iostream>
#include <errno.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include <deque>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <vector>
#include <map>
#include <sstream>
#include <iomanip>
#include <list>
#include <string.h>
#include <stdint.h>
#include <sstream>
#include <utility>

using namespace std;
