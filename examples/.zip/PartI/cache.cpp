#include "cache.h"

using namespace std;

cache::cache(){

}

void cache::fetchMemoryRef(){

}

void cache::runSim(){

}

void cache::printDebug(){

}