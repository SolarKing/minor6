#include "defs.h"

class reporter{
	private:
		
	public:
		reporter();
		void createReport();
		void GetDisplayOptions();
};
